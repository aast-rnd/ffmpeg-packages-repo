/*****************************************************************************/

Documentation summary

 'doc/introduction.txt' to know the purpose of the project

 'doc/projectmanangement.txt' to know the organisation of files and directories.

 'doc/avancement.txt' to know the progress in the development of the project

/*****************************************************************************/

1. Run getsources.sh (without sudo) to get the sources of gpac and/or webkit if necessary

2. Run 'sudo ./install.sh' with the appropriate parameter (full, player, gpac, webkit or dependencies)
