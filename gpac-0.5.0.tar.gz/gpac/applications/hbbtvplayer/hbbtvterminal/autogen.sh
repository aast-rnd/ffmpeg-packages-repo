
#! /bin/sh

autoreconf --install -v

./configure
