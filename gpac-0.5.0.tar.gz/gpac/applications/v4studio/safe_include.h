#ifndef _SAFE_INCLUDE_H 
#define _SAFE_INCLUDE_H 

#include <gpac/setup.h>

#endif

